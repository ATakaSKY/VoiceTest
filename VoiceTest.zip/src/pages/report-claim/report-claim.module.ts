import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReportClaimPage } from './report-claim';

@NgModule({
  declarations: [
    ReportClaimPage,
  ],
  imports: [
    IonicPageModule.forChild(ReportClaimPage),
  ],
})
export class ReportClaimPageModule {}
