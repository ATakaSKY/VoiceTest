import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ClaimDetailsVoicePage } from './claim-details-voice';

@NgModule({
  declarations: [
    ClaimDetailsVoicePage,
  ],
  imports: [
    IonicPageModule.forChild(ClaimDetailsVoicePage),
  ],
})
export class ClaimDetailsVoicePageModule {}
